from flask import Flask, render_template, request, send_file, send_from_directory
from TTS.api import TTS
import torch
import os

app = Flask(__name__)

# Initialize TTS
device = "cuda" if torch.cuda.is_available() else "cpu"

@app.route('/')
def upload_form():
    return render_template('index.html')

@app.route('/generate-audio', methods=['POST'])
def generate_audio():
    # Retrieve text input from the form
    text_input = request.form['text-input']
    # Initialize TTS
    tts = TTS(model_name="tts_models/en/ljspeech/tacotron2-DCA", progress_bar=False).to(device)
    # Generate audio from text input using Tacotron2-DCA model
    audio_path = '/content/drive/MyDrive/Text-to-audio/static/predictions/output.wav'
    tts.tts_to_file(text=text_input, file_path=audio_path)
    # Return the file path of the generated audio
    
    return render_template('display_audio.html')

if __name__ == '__main__':
    app.run()
