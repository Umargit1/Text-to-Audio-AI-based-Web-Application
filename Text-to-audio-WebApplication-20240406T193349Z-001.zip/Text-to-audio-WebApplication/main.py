import torch
from TTS.api import TTS

def generate_audio(text_input):
    # Get device
    device = "cuda" if torch.cuda.is_available() else "cpu"
    # Init TTS with the target model name
    tts = TTS(model_name="tts_models/en/ljspeech/tacotron2-DCA", progress_bar=False).to(device)

# Run TTS
    tts.tts_to_file(text=text_input, file_path='/content/drive/MyDrive/Text-to-audio/static/predictions/output.wav')
   
    
    
if __name__ == "__main__":
    text_input = input("Enter the text you want to convert to audio: ")
    generate_audio(text_input)
    
